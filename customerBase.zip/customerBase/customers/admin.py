from django.contrib import admin

from customers.models import Customers

admin.site.register(Customers)
